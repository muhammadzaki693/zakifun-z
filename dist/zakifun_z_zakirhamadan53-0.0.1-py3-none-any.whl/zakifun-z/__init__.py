def test():
    print("alive")