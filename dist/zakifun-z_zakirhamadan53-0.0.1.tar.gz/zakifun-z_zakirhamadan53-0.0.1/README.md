# zakifun-z
gatatu
# instalaion
```
pip install zakifun
```